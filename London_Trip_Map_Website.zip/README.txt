Upload index.html to GitHub Pages, Netlify, or another static website host.
Do not open it as a local file on iPhone; iPhone preview blocks map tiles/scripts.
